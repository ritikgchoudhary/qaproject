<script setup>
import { ref } from 'vue'
import axios from 'axios'
import { useRouter } from 'vue-router'

import { useUserStore } from '../stores/user'

const userStore = useUserStore()
const loading = ref(false)
const message = ref('')
const error = ref('')
const router = useRouter()
const amount = ref(100)
const isAlreadyDeposited = ref(false)
const mustWithdrawFirst = ref(false)
const selectedChannel = ref('WATCHPAY')
const paymentUrl = ref('')
const showManualRedirect = ref(false)
const channelErrors = ref({ WATCHPAY: '' })
const currentChannelIndex = ref(0)
const channels = ['WATCHPAY']

async function initialize() {
    loading.value = true
    await userStore.fetchUser()
    if (userStore.user) {
        amount.value = userStore.user.next_deposit_required || 100
        
        // Check if current balance is already >= required amount
        const withdrawableVal = parseFloat(userStore.wallet?.withdrawable_balance || 0)
        const currentLevel = parseInt(userStore.user.current_level || userStore.user.level || 1, 10)
        
        // FEATURE 1: Block deposit if previous level funds are sufficient
        if (currentLevel > 1 && withdrawableVal >= amount.value) {
            mustWithdrawFirst.value = true
        }
        if (withdrawableVal >= amount.value) {
            isAlreadyDeposited.value = true
        }
    }
    loading.value = false
}

initialize()

async function tryChannel(channel) {
    try {
        console.log('Trying channel:', channel)
        const res = await axios.post('/api/deposit.php', {
            channel: channel
        }, {
            timeout: 10000
        })
        
        console.log('API Response:', res.data)
        
        if (res.data.success && res.data.payment_url) {
            console.log('Payment URL received:', res.data.payment_url)
            return {
                success: true,
                payment_url: res.data.payment_url,
                channel: channel
            }
        } else {
            const errorMsg = res.data.error || 'Payment gateway error'
            console.error('API Error:', errorMsg)
            return {
                success: false,
                error: errorMsg,
                channel: channel
            }
        }
    } catch(e) {
        const errorMsg = e.response?.data?.error || e.message || 'Network error'
        console.error('Network Error:', errorMsg, e)
        return {
            success: false,
            error: errorMsg,
            channel: channel
        }
    }
}

async function makeDeposit() {
    if (loading.value) return // Prevent double clicks
    loading.value = true
    message.value = ''
    error.value = ''
    showManualRedirect.value = false
    paymentUrl.value = ''
    channelErrors.value = { WATCHPAY: '' }
    currentChannelIndex.value = 0
    
    // Use WatchPay only
    let result = await tryChannel('WATCHPAY')
    
    if (result.success) {
        // Success with WatchPay
        console.log('Setting payment URL:', result.payment_url)
        paymentUrl.value = result.payment_url
        
        // Always show manual button immediately
        showManualRedirect.value = true
        
        // Direct GET redirect with parameters - open in new tab
        message.value = `Opening payment gateway...`
        
        // Try to open in new tab immediately
        try {
            console.log('Attempting to open:', result.payment_url)
            const newWindow = window.open(result.payment_url, '_blank', 'noopener,noreferrer')
            
            // Wait a bit to check if window was blocked
            setTimeout(() => {
                if (!newWindow || newWindow.closed || typeof newWindow.closed === 'undefined') {
                    // Popup blocked
                    console.warn('Popup blocked or failed to open')
                    message.value = 'Popup blocked. Please click the button below to open payment gateway.'
                } else {
                    // Successfully opened
                    console.log('Payment gateway opened successfully')
                    message.value = 'Payment gateway opened in new tab. Complete payment there.'
                }
            }, 500)
        } catch (e) {
            console.error('Error opening window:', e)
            message.value = 'Please click the button below to open payment gateway.'
        }
        
        loading.value = false
        return
    }
    
    // WatchPay failed
    channelErrors.value.WATCHPAY = result.error
    error.value = result.error || 'Payment gateway error. Please try again later.'
    message.value = ''
    loading.value = false
}
</script>

<template>
  <div class="page-wrapper">
      <h2 class="page-title text-gold-gradient">Add Funds</h2>
      
      <div class="glass-card deposit-card">
          <div class="icon-container">
               <img src="https://img.icons8.com/3d-fluency/94/wallet.png" width="64" />
          </div>
          <p class="label">Deposit Amount</p>
           <p class="amount">₹{{ amount }}</p>
          <p class="info-text">Activates your account for withdrawals</p>
      </div>
      
      <!-- WatchPay Payment Gateway -->
      <div class="glass-card channel-selection">
          <p class="label">Payment Method</p>
          <div class="channel-options" style="grid-template-columns: 1fr;">
              <button 
                  :class="['channel-btn', { active: true, error: channelErrors.WATCHPAY }]"
                  :disabled="loading || isAlreadyDeposited || mustWithdrawFirst"
                  style="cursor: default;"
              >
                  <span class="channel-icon">💳</span>
                  <span class="channel-name">WatchPay</span>
                  <span class="channel-desc">Secure Payment Gateway</span>
                  <span v-if="channelErrors.WATCHPAY" class="channel-error">❌</span>
              </button>
          </div>
          <!-- Show channel errors if any -->
          <div v-if="channelErrors.WATCHPAY" class="channel-errors">
              <p class="error-label">Payment Error:</p>
              <p class="error-text">WatchPay: {{ channelErrors.WATCHPAY }}</p>
          </div>
      </div>
      
      <button 
          @click.prevent="makeDeposit" 
          :disabled="loading || isAlreadyDeposited || mustWithdrawFirst" 
          class="btn-action"
          type="button"
      >
          <span v-if="loading">Processing...</span>
          <span v-else-if="mustWithdrawFirst">WITHDRAW FIRST</span>
          <span v-else-if="isAlreadyDeposited">FUNDS ALREADY ADDED</span>
          <span v-else>PAY ₹{{ amount }} NOW</span>
      </button>
      
       <div v-if="mustWithdrawFirst" class="glass-card mt-4 p-4 border-yellow-500/20 bg-yellow-500/10">
           <p class="text-yellow-400 text-sm font-bold">⚠️ Please withdraw your previous level funds to unlock the next level deposit.</p>
           <button @click="router.push('/withdraw')" class="mt-2 text-xs underline text-white">Go to Withdraw</button>
       </div>

       <div v-if="isAlreadyDeposited" class="glass-card mt-4 p-4 border-yellow-500/20 bg-yellow-500/10">
           <p class="text-yellow-400 text-sm font-bold">⚠️ You already have the required funds in your wallet. You can proceed to play the quiz.</p>
           <button @click="router.push('/dashboard')" class="mt-2 text-xs underline text-white">Go to Dashboard</button>
       </div>

       <div v-if="message" class="glass-card message success">{{ message }}</div>
       <div v-if="error" class="glass-card message error">{{ error }}</div>
       
       <!-- Manual Redirect Button (Always shown when payment URL is ready) -->
       <div v-if="showManualRedirect && paymentUrl" class="glass-card mt-4 p-4 border-blue-500/20 bg-blue-500/10">
           <p class="text-blue-400 text-sm font-bold mb-3">💳 Click below to open payment gateway:</p>
           <a 
               :href="paymentUrl" 
               target="_blank" 
               rel="noopener noreferrer" 
               class="btn-action" 
               style="text-decoration: none; display: block; text-align: center; background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); cursor: pointer;"
           >
               🔗 OPEN PAYMENT GATEWAY
           </a>
       </div>
       
       <!-- Hidden form for direct submission (backup) -->
       <form v-if="paymentUrl" :action="paymentUrl" method="GET" ref="paymentForm" style="display: none;">
       </form>
  </div>
</template>

<style scoped>
@reference "../assets/main.css";

.page-wrapper {
    padding: 1rem;
    padding-bottom: 90px;
    max-width: 480px;
    margin: 0 auto;
    font-family: 'Inter', sans-serif;
    text-align: center;
    @apply w-full min-h-screen bg-[#050505] text-white;
}
.page-title {
    font-size: 1.5rem;
    font-weight: 800;
    margin-bottom: 1.5rem;
    background: linear-gradient(to right, #fbbf24, #f59e0b);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    text-transform: uppercase; 
    letter-spacing: 1px;
}

.deposit-card {
    padding: 2rem;
    display: flex;
    flex-direction: column;
    align-items: center;
    background: #111;
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 16px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.3);
}
.icon-container {
    margin-bottom: 1rem;
    filter: drop-shadow(0 0 10px rgba(251, 191, 36, 0.3));
}
.label {
    color: #94a3b8;
    font-size: 0.9rem;
    text-transform: uppercase;
    font-weight: 600;
    margin-bottom: 0.5rem;
}
.amount {
    font-size: 3.5rem;
    font-weight: 900;
    color: #fff;
    text-shadow: 0 0 30px rgba(255,255,255,0.2);
    margin-bottom: 0.5rem;
}
.info-text {
    color: #fbbf24;
    font-size: 0.8rem;
    background: rgba(251, 191, 36, 0.1);
    padding: 0.4rem 1rem;
    border-radius: 20px;
    border: 1px solid rgba(251, 191, 36, 0.2);
}

.btn-action {
    width: 100%;
    padding: 1rem;
    background: linear-gradient(135deg, #10b981 0%, #059669 100%);
    color: white;
    font-size: 1.1rem;
    font-weight: 800;
    border: none;
    border-radius: 12px;
    cursor: pointer;
    box-shadow: 0 4px 15px rgba(16, 185, 129, 0.2);
    transition: transform 0.2s;
    margin-top: 1.5rem;
}
.btn-action:hover:not(:disabled) { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(16, 185, 129, 0.4); }
.btn-action:disabled { background: #1f2937; box-shadow: none; cursor: not-allowed; color: #64748b; }

.message { margin-top: 1.5rem; padding: 1rem; font-weight: 600; background: #111; border: 1px solid rgba(255,255,255,0.1); border-radius: 12px; }
.success { color: #4ade80; border-color: rgba(74, 222, 128, 0.3); background: rgba(74, 222, 128, 0.1); }
.error { color: #f87171; border-color: rgba(248, 113, 113, 0.3); background: rgba(248, 113, 113, 0.1); }

.channel-selection {
    margin-top: 1.5rem;
    padding: 1.5rem;
    background: #111;
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 16px;
}

.channel-options {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 0.75rem;
    margin-top: 1rem;
}

.channel-btn {
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 1rem 0.5rem;
    background: #1a1a1a;
    border: 2px solid rgba(255,255,255,0.1);
    border-radius: 12px;
    cursor: pointer;
    transition: all 0.3s;
    color: white;
}

.channel-btn:hover:not(:disabled) {
    border-color: rgba(251, 191, 36, 0.5);
    background: rgba(251, 191, 36, 0.1);
    transform: translateY(-2px);
}

.channel-btn.active {
    border-color: #fbbf24;
    background: rgba(251, 191, 36, 0.15);
    box-shadow: 0 0 20px rgba(251, 191, 36, 0.3);
}

.channel-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

.channel-icon {
    font-size: 1.5rem;
    margin-bottom: 0.5rem;
}

.channel-name {
    font-weight: 700;
    font-size: 0.9rem;
    margin-bottom: 0.25rem;
}

.channel-desc {
    font-size: 0.7rem;
    color: #94a3b8;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.channel-info {
    font-size: 0.75rem;
    color: #64748b;
    margin-top: 0.5rem;
    margin-bottom: 0.5rem;
    font-style: italic;
}

.channel-btn.error {
    border-color: rgba(239, 68, 68, 0.5) !important;
    background: rgba(239, 68, 68, 0.1) !important;
}

.channel-error {
    position: absolute;
    top: 5px;
    right: 5px;
    font-size: 0.8rem;
    color: #ef4444;
}

.channel-errors {
    margin-top: 1rem;
    padding: 0.75rem;
    background: rgba(239, 68, 68, 0.1);
    border: 1px solid rgba(239, 68, 68, 0.3);
    border-radius: 8px;
    text-align: left;
}

.error-label {
    font-size: 0.75rem;
    font-weight: 700;
    color: #ef4444;
    margin-bottom: 0.5rem;
    text-transform: uppercase;
}

.error-text {
    font-size: 0.7rem;
    color: #fca5a5;
    margin: 0.25rem 0;
    word-break: break-word;
}
</style>
