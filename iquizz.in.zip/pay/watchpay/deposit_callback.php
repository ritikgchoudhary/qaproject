<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$host = '72.60.96.75';
$db_name = 'qa_platform';
$username = 'qa_platform';
$password = 'qa_platform';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db_name;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    error_log("WatchPay Callback DB Error: " . $e->getMessage());
    http_response_code(500);
    exit("DB error");
}

// Log function
function logToFile($msg) {
    $logFile = __DIR__ . "/callback_log.txt";
    file_put_contents($logFile, date("Y-m-d H:i:s") . " - " . $msg . "\n", FILE_APPEND);
}

// Collect POST parameters
$tradeResult = $_POST['tradeResult'] ?? '';
$mchId = $_POST['mchId'] ?? '';
$mchOrderNo = $_POST['mchOrderNo'] ?? '';
$oriAmount = $_POST['oriAmount'] ?? ($_POST['originalAmount'] ?? '');
$amount = $_POST['amount'] ?? '';
$orderDate = $_POST['orderDate'] ?? '';
$orderNo = $_POST['orderNo'] ?? '';
$merRetMsg = $_POST['merRetMsg'] ?? '';
$signType = $_POST['signType'] ?? '';
$sign = $_POST['sign'] ?? '';

logToFile("Callback received - Order: $mchOrderNo, Result: $tradeResult, Amount: $amount");

// Validate Signature
$merchantKey = "49fd706f0a924b679df02131a3df8794";

// Build sign string (exclude sign & signType & empty)
$params = $_POST;
unset($params['sign'], $params['signType']);
$params = array_filter($params, function($v) { return $v !== '' && $v !== null; });

// Sort by ASCII order
ksort($params);

// Query string
$queryString = "";
foreach ($params as $k => $v) {
    $queryString .= $k . "=" . $v . "&";
}
$queryString .= "key=" . $merchantKey;

// MD5 lower
$checkSign = strtolower(md5($queryString));

if ($checkSign !== $sign) {
    logToFile("❌ Invalid signature. Received: $sign, Expected: $checkSign");
    http_response_code(400);
    exit("sign error");
}

logToFile("✅ Signature verified");

// Check if success
if ($tradeResult != "1") {
    logToFile("❌ Payment failed. tradeResult=$tradeResult for Order=$mchOrderNo");
    
    // Update deposit status to failed
    try {
        $stmt = $pdo->prepare("UPDATE deposits SET status = 'failed' WHERE order_id = ?");
        $stmt->execute([$mchOrderNo]);
    } catch (Exception $e) {
        logToFile("❌ Failed to update deposit status: " . $e->getMessage());
    }
    
    http_response_code(200);
    exit("fail");
}

// Payment Success - Process order
logToFile("✅ Payment successful for Order: $mchOrderNo, Amount: $amount");

try {
    $pdo->beginTransaction();
    
    // Find deposit record
    $stmt = $pdo->prepare("SELECT id, user_id, amount, status FROM deposits WHERE order_id = ? AND status = 'pending'");
    $stmt->execute([$mchOrderNo]);
    $deposit = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$deposit) {
        logToFile("⚠️ Deposit not found or already processed: $mchOrderNo");
        $pdo->rollBack();
        http_response_code(200);
        echo "success"; // Already processed, still reply success
        exit;
    }
    
    $deposit_id = $deposit['id'];
    $user_id = $deposit['user_id'];
    $deposit_amount = $deposit['amount'];
    
    logToFile("💰 Processing deposit - User: $user_id, Amount: $deposit_amount, Deposit ID: $deposit_id");
    
    // Update deposit status to success
    $stmt = $pdo->prepare("UPDATE deposits SET status = 'success' WHERE id = ?");
    $stmt->execute([$deposit_id]);
    
    // Add to withdrawable balance (merged wallet)
    $stmt = $pdo->prepare("
        INSERT INTO wallets (user_id, withdrawable_balance) 
        VALUES (?, ?) 
        ON DUPLICATE KEY UPDATE withdrawable_balance = withdrawable_balance + ?
    ");
    $stmt->execute([$user_id, $deposit_amount, $deposit_amount]);
    
    // Mark user as deposited
    $stmt = $pdo->prepare("UPDATE users SET has_deposited = 1 WHERE id = ?");
    $stmt->execute([$user_id]);
    
    // Log transaction
    $stmt = $pdo->prepare("INSERT INTO transactions (user_id, type, amount, description) VALUES (?, 'deposit', ?, 'Deposit via WatchPay - Order: $mchOrderNo')");
    $stmt->execute([$user_id, $deposit_amount]);
    
    // Distribute agent commissions (10% to agents up to 3 levels)
    include __DIR__ . '/../../api/utils.php';
    distributeAgentCommissions($pdo, $user_id, $deposit_amount);
    
    // Check and distribute tree bonus (₹30 when tree completes)
    checkAndDistributeTreeBonus($pdo, $user_id);
    
    // Auto level up
    autoLevelUp($pdo, $user_id);
    
    $pdo->commit();
    
    logToFile("✅ Deposit processed successfully - User: $user_id, Amount: $deposit_amount");
    
    // Important: Tell gateway "success"
    http_response_code(200);
    echo "success";
    exit;
    
} catch (Exception $e) {
    $pdo->rollBack();
    logToFile("❌ Error processing deposit: " . $e->getMessage());
    http_response_code(500);
    echo "error";
    exit;
}
?>
